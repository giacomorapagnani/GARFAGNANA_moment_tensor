from obspy import read, UTCDateTime, read_inventory
from obspy.signal import PPSD
from obspy.io.xseed import Parser

stazione='UP01'
# Path to your dataless SEED file
dataless_file = '/Users/francesco/Dati/Garfagnana/metadati/'+stazione+'.dataless'

# Read the dataless file
parser = Parser(dataless_file)

# Write as StationXML
parser.write_xseed('/Users/francesco/Dati/Garfagnana/metadati/'+stazione+'.xseed.xml')
inv = read_inventory('/Users/francesco/Dati/Garfagnana/metadati/'+stazione+'.xseed.xml')
inv.write('/Users/francesco/Dati/Garfagnana/metadati/'+stazione+'.xml', format='STATIONXML')